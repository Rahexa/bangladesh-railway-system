<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <style>
        /* Your existing CSS styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        form {
            position: absolute;
            top: 52%;
            left: 17%;
            transform: translate(-50%, -50%);
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            padding: 20px;
            max-width: 400px;
            color: #151B4F;
        }

        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        form input[type="text"],
        form input[type="date"],
        form input[type="number"],
        form select {
            width: calc(100% - 12px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        form input[type="submit"] {
            background: #151B4F;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 20px;
            cursor: pointer;
            transition: background 0.3s ease;
            margin: 0 auto;
            display: block;
        }

        form input[type="submit"]:hover {
            background: #0056b3;
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 40%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            width: 250px;
            text-align: center;
            animation: fadeIn 0.3s ease-in-out;
        }

        .popup h2 {
            font-size: 22px;
            margin-bottom: 15px;
            color: #151B4F;
            font-weight: bold;
        }

        .popup p {
            font-size: 16px;
            color: #333;
            margin-bottom: 20px;
        }

        .btn {
            width: 100%;
            background-color: rgb(65, 202, 127);
            color: white;
            justify-content: center;
            padding: 12px 0;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background-color: rgb(50, 180, 110);
        }

        .amount {
            font-size: 26px;
            font-weight: bold;
            color: #151B4F;
            margin-bottom: 20px;
        }

        .payment-options {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 10px;
        }

        .payment-btn {
            background: #f8f8f8;
            border: 2px solid #ddd;
            border-radius: 8px;
            padding: 12px;
            font-size: 16px;
            color: #151B4F;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .payment-btn:hover {
            background: #151B4F;
            color: white;
            border-color: #151B4F;
        }
    </style>
</head>

<body>
    <div id="bookingForm">
        <form id="bookingFormElement" action="#" method="POST">
            <div style="display: flex; flex-wrap: wrap;">
                <div style="flex: 1; margin-right: 10px;">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div style="flex: 1; margin-right: 10px;">
                    <label for="age">Age:</label>
                    <input type="number" id="age" name="age" required>
                </div>
                <div style="flex: 1;">
                    <label for="sex">Sex:</label>
                    <select id="sex" name="sex" required>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
            </div>
            <div style="display: flex; flex-wrap: wrap;">
                <div style="flex: 1; margin-right: 10px;">
                    <label for="from">From:</label>
                    <select id="from" name="from" required>
                        <!-- Options will be dynamically populated here -->
                    </select>
                </div>
                <div style="flex: 1; margin-right: 10px;">
                    <label for="to">To:</label>
                    <select id="to" name="to" required>
                        <!-- Options will be dynamically populated here -->
                    </select>
                </div>
            </div>
            <div style="display: flex; flex-wrap: wrap;">
                <div style="flex: 1; margin-right: 10px;">
                    <label for="date">Date of Journey:</label>
                    <input type="date" id="date" name="date" required>
                </div>
                <div style="flex: 1; margin-right: 10px;">
                    <label for="journeyType">Journey Type:</label>
                    <select id="journeyType" name="journeyType">
                        <option value="oneWay">One Way</option>
                        <option value="roundTrip">Round Trip</option>
                    </select>
                </div>
            </div>
            <div style="display: flex; flex-wrap: wrap;">
                <div style="flex: 1; margin-right: 10px;">
                    <label for="class">Class:</label>
                    <select id="class" name="class">
                        <option value="economy">Economy</option>
                        <option value="business">Business</option>
                        <option value="firstClass">First Class</option>
                    </select>
                </div>
                <div style="flex: 1;">
                    <label for="ticketType">Ticket Type:</label>
                    <select id="ticketType" name="ticketType">
                        <option value="adult">Adult</option>
                        <option value="children">Children</option>
                    </select>
                </div>
            </div>
            <div style="display: flex; flex-wrap: wrap;">
                <div style="flex: 1; margin-right: 10px;">
                    <label for="numberOfTickets">Number of Tickets:</label>
                    <input type="number" id="numberOfTickets" name="numberOfTickets" min="1" value="1" required>
                </div>
                <div style="flex: 1;">
                    <label for="contactNo">Contact No:</label>
                    <input type="text" id="contactNo" name="contactNo" required>
                </div>
            </div>
            <input type="submit" value="Submit" style="font-weight: bold;">
        </form>
    </div>

    <!-- Total Payment Popup -->
    <div class="popup" id="totalPaymentPopup">
        <div class="card">
            <h2 class="card-title">Total Payment</h2>
            <p class="amount" id="ticketPrice">Ticket Price: $0.00</p>
            <p class="amount" id="vatAmount">VAT (10%): $0.00</p>
            <p class="amount" id="routeDetails">Route: From - To</p>
            <p class="amount" id="totalAmount">Total Payment: $0.00</p>
            
            <button class="btn" id="proceedToPayment">Proceed to Payment</button>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            // Populate dropdowns with station options
            const bangladeshiStations = [
                'Dhaka Junction',
                'Chittagong Central',
                'Khulna Terminal',
                'Rajshahi Station',
                'Sylhet Junction',
                'Barisal Central',
                'Rangpur Terminal',
                'Comilla Junction',
                'Mymensingh Central',
                'Jessore Station'
            ];

            function populateDropdowns() {
                const fromDropdown = $('#from');
                const toDropdown = $('#to');

                bangladeshiStations.forEach(function (station) {
                    fromDropdown.append(new Option(station, station));
                    toDropdown.append(new Option(station, station));
                });
            }

            populateDropdowns();

            $('#bookingFormElement').on('submit', function (e) {
                e.preventDefault();
                const from = $('#from').val();
                const to = $('#to').val();
                const classType = $('#class').val();
                const ticketType = $('#ticketType').val();
                const numberOfTickets = $('#numberOfTickets').val();

                $.ajax({
                    type: 'POST',
                    url: '/get-ticket-price',
                    data: {
                        from: from,
                        to: to,
                        class: classType,
                        ticketType: ticketType,
                        numberOfTickets: numberOfTickets,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function (response) {
                        if (response.success) {
                            const ticketPrice = response.ticketPrice;
                            const vatAmount = (ticketPrice * 0.10).toFixed(2);
                            const totalAmount = (parseFloat(ticketPrice) + parseFloat(vatAmount)).toFixed(2);
                            
                            $('#ticketPrice').text('Ticket Price: $' + ticketPrice);
                            $('#vatAmount').text('VAT (10%): $' + vatAmount);
                            $('#routeDetails').text('Route: ' + from + ' - ' + to);
                            $('#totalAmount').text('Total Payment: $' + totalAmount);
                            
                            $('#totalPaymentPopup').fadeIn();
                        } else {
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('AJAX Error:', error);
                    }
                });
            });

            // Redirect to payment page on button click
            $('#proceedToPayment').on('click', function () {
                const from = $('#from').val();
                const to = $('#to').val();
                const classType = $('#class').val();
                const ticketType = $('#ticketType').val();
                const numberOfTickets = $('#numberOfTickets').val();
                const contactNo = $('#contactNo').val();
                const totalAmount = $('#totalAmount').text().replace('Total Payment: $', '');

                // Redirect to the payment page with the necessary data
                window.location.href = '<?php echo e(url('/pay')); ?>?from=' + encodeURIComponent(from) +
                    '&to=' + encodeURIComponent(to) +
                    '&class=' + encodeURIComponent(classType) +
                    '&ticketType=' + encodeURIComponent(ticketType) +
                    '&numberOfTickets=' + encodeURIComponent(numberOfTickets) +
                    '&contactNo=' + encodeURIComponent(contactNo) +
                    '&amount=' + encodeURIComponent(totalAmount);
            });
        });
    </script>
    
</body>

</html><?php /**PATH C:\xampp\htdocs\railway-system\resources\views/bookingform.blade.php ENDPATH**/ ?>