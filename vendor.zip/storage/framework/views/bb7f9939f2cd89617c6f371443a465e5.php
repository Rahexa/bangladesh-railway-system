<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            color: #333;
        }

        /* Header Styles */
        .header {
            background-color: rgba(255, 255, 255, 0.9);
            width: 100%;
            height: 60px;
            padding: 10px 20px;
            position: fixed;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            color: #007bff;
            font-weight: bold;
            font-size: 24px;
        }

        .rail-logo {
            width: 50px;
            height: auto;
        }

        /* Login Page Styles */
        .login-page {
            padding-top: 70px;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('image/metro1.jpg');
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .login-box {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 400px;
            position: relative;
            z-index: 1;
        }

        .login-text {
            text-align: center;
            margin-bottom: 20px;
        }

        .login-text h1 {
            color: #333;
            margin-bottom: 10px;
        }

        .login-text p {
            font-size: 16px;
            color: #666;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .login-box input[type="email"],
        .login-box input[type="password"] {
            height: 40px;
            padding: 0 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
            transition: border-color 0.3s;
        }

        .login-box input[type="email"]:focus,
        .login-box input[type="password"]:focus {
            border-color: #007bff;
            outline: none;
        }

        .login-box button.btn {
            width: 100%;
            height: 40px;
            background: #007bff;
            border: none;
            color: #fff;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .login-box button.btn:hover {
            background: #0056b3;
        }

        .login-social {
            text-align: center;
            margin-top: 20px;
        }

        .login-social h3 {
            color: #333;
            margin-bottom: 10px;
        }

        .login-social-buttons {
            display: flex;
            justify-content: center;
        }

        .login-social-buttons a {
            margin: 0 10px;
        }

        .login-social-buttons img {
            width: 30px;
            height: 30px;
        }

        .remember-text {
            color: #666;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 5px;
            text-align: center;
        }

        /* Responsive Styles */
        @media (max-width: 480px) {
            .login-box {
                width: 90%;
            }
        }
    </style>
</head>
<body>
<div class="header">
    <div>
        <img src="image/logo.png" alt="Rail Logo" class="rail-logo">
    </div>
    <h1>Bangladesh Railway</h1>
    <div>
        <img src="image/mlogo.png" alt="Rail Logo" class="rail-logo">
    </div>
</div>
<div class="login-page">
    <div class="login-box">
        <div class="login-text">
            <h1>SIGN IN <i class="fa fa-lock" style="margin-left: 10px;"></i></h1>
            <p>Enter your username and password to log on:</p>
            <?php if(session('login_error')): ?>
                <div class="error-message"><?php echo e(session('login_error')); ?></div>
            <?php endif; ?>
        </div>
        <form role="form" action="<?php echo e(route('login')); ?>" method="post" class="login-form">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email..." class="form-control" id="l-form-email" required>
            </div>
            <div class="form-group position-relative">
                <input type="password" name="password" placeholder="Password..." class="form-control" id="l-form-password" required>
                <i class="fas fa-eye" id="togglePassword" style="position: absolute; right: 15px; top: 10px; cursor: pointer;"></i>
            </div>
            <button type="submit" class="btn">Sign in!</button>
            <div class="text-center">
                <label class="checkbox-inline">
                    <input type="checkbox"> <span class="remember-text">Remember me</span>
                </label>
                <p style="margin-top: 10px;">Don't have an account? <a href="<?php echo e(route('register')); ?>" style="color: deepskyblue;">Sign up</a>.</p>
            </div>
        </form>
        <div class="login-social">
            <h3>...or login with:</h3>
            <div class="login-social-buttons">
                <a href="https://google.com"><img src="image/google.png" alt="Google"></a>
                <a href="https://twitter.com"><img src="image/twt.png" alt="Twitter"></a>
                <a href="https://facebook.com"><img src="image/fb.png" alt="Facebook"></a>
            </div>
        </div>
    </div>
</div>
<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#l-form-password');

    togglePassword.addEventListener('click', function () {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\railway-system\resources\views/auth/login.blade.php ENDPATH**/ ?>