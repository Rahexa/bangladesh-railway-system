<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Checkout | SSLCommerz</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .btn-custom {
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: white;
            border-radius: 8px;
        }
        .btn-custom:hover {
            background: linear-gradient(45deg, #0056b3, #004094);
        }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row">
        <div class="col-md-5">
            <div class="card p-3">
                <h4 class="mb-3">Your Cart</h4>
                <ul class="list-group mb-3">
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">Product 1</h6>
                            <small class="text-muted">Description</small>
                        </div>
                        <span class="text-muted">1000 TK</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">Product 2</h6>
                            <small class="text-muted">Description</small>
                        </div>
                        <span class="text-muted">50 TK</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">Product 3</h6>
                            <small class="text-muted">Description</small>
                        </div>
                        <span class="text-muted">150 TK</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Total (BDT)</span>
                        <strong>1200 TK</strong>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-md-7">
            <div class="card p-4">
                <h4 class="mb-3">Billing Information</h4>
                <form action="<?php echo e(url('/pay')); ?>" method="POST">
                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="customer_name" class="form-control" value="John Doe" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Mobile</label>
                        <input type="text" name="customer_mobile" class="form-control" value="01711xxxxxx" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="customer_email" class="form-control" value="you@example.com" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <input type="text" class="form-control" value="93 B, New Eskaton Road" required>
                    </div>
                    <input type="hidden" value="1200" name="amount" required />
                    <button class="btn btn-custom w-100 mt-3" type="submit">Proceed to Payment</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\railway-system\resources\views/exampleHosted.blade.php ENDPATH**/ ?>