
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh Railway</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        header {
            background-image: url('https://st4.depositphotos.com/3570295/20491/i/450/depositphotos_204913566-stock-photo-moving-train-track-double-exposure.jpg');
            background-size: cover;
            height: 8vh;
            background-position: center;
            padding: 10px;
            text-align: center;
            position: relative;
        }

        header h1 {
            font-size: 60px;
            font-weight: 500;
            color: white;
        }

        nav {
            display: flex;
            justify-content: center;
            margin-top: 10px;
        }

        nav a {
            text-decoration: none;
            color: #031876;
            font-weight: bold;
            padding: 10px 20px;
            margin: 0 5px;
            background-color: #fff;
            border: 2px solid #fff;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 1);
        }

        nav a:hover {
            background-color: #151B4F;
            color: #fff;
        }

        img {
            display: block;
            margin: auto;
            margin-top: 1px;
            width: 100%;
            max-height: 683px;
            height: auto;
        }

        .news-ticker-container {
            font-family: Arial, sans-serif;
            overflow: hidden;
            white-space: nowrap;
            position: absolute;
            top: 125px;
            left: 0;
            right: 0;
            background-color: rgba(0, 0, 0, 1);
            color: #29f516;
            padding: 10px 0;
            animation: ticker-scroll 20s linear infinite;
        }

        @keyframes ticker-scroll {
            0% {
                transform: translateX(100%);
            }
            100% {
                transform: translateX(-100%);
            }
        }

        .menu-icon {
            position: fixed;
            top: 20px;
            right: 20px;
            cursor: pointer;
            z-index: 999;
        }

        .menu-icon div {
            width: 35px;
            height: 5px;
            background-color: black;
            margin: 6px 0;
        }

        .menu-content {
            display: none;
            position: fixed;
            background-color: #f1f1f1;
            width: 160px;
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
            z-index: 999;
            top: 40px;
            right: 25px;
        }

        .menu-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .menu-content a:hover {
            background-color: #ddd;
        }

        .show {
            display: block;
        }

        #logoutButton {
            display: none;
            position: absolute;
            top: 40px;
            right: 10px;
            background-color: #151B4F;
            color: #ffff;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        #clock {
            position: absolute;
            top: 20px;
            right: 80px;
            color: white;
            font-size: 30px;
        }

        #bookingInstructions {
            position: absolute;
            top: 60%;
            right: -15%;
            transform: translate(-50%, -50%);
            background-color: rgba(255, 255, 255, 0);
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
            color: #151B4F;
        }
    </style>
</head>

<body>

<header>

    <div class="header-background"></div>

    <div class="header-content">

        <div id="clock"></div>

        <font size="50" color="#81D4FA"><b>Bangladesh Railway</b></font>

        <div class="menu-icon" onclick="toggleLogoutButton(); toggleMenu();">

            <div></div>

            <div></div>

            <div></div>

        </div>

        <nav>

            <a href="home.php">Home</a>

            <a href="javascript:void(0);" onclick="showBookingForm()">Booking</a> <!-- Updated link -->

            <a href="seat.php">Seats Availability</a>

            <a href="trainlist.php">Train List</a>

            <a href="tracking.php">Train Route Tracking</a>

            <a href="ticket.php">My Booking</a>

            <a href="contact.php">About us</a>

            <a href="about us.php">Contact us</a>

            <a href="https://www.google.com.bd/maps/search/bangladesh+all+rail+station/@23.5033387,90.50561,7z?entry=ttu">Map</a>

        </nav>

    </div>

</header>


<div class="news-ticker-container">

    <div class="news-item"> 🚂<b>Welcome to Bangladesh Railway*** The iconic 'Padma Express' will arrive at Dhaka Station at 10:45 AM and depart at 11:15 AM! Plan your journey accordingly! 🚆-</b></div>

</div>


<div id="bookingInstructions">

    <h2>Booking Instructions</h2>

    <p>1. Fill out the form with your details.</p>

    <p>2. Select your departure and destination stations.</p>

    <p>3. Choose the date of your journey.</p>

    <p>4. Select the class and ticket type.</p>

    <p>5. Choose your payment method and proceed with payment.</p>

    <p>6. If applicable, enter the transaction ID.</p>

    <p>7. Click the "Submit" button to confirm your booking.</p>

</div>


<!-- Booking Form Section -->

<div id="bookingFormContainer" style="display: none;">

    <?php echo $__env->make('bookingform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Assuming your booking form is in a separate Blade file -->

</div>


<img src="https://dhz-coxb-railway.com/wp-content/uploads/2021/05/Picture25.jpg">


<button id="logoutButton" onclick="logout()">Logout</button>


<div class="menu-content">

    <a href="<?php echo e(route('profile')); ?>">My Account</a>

    <a href="login">LogOut</a>

</div>


<script>

    function updateClock() {

        var now = new Date();

        var hours = now.getHours();

        var minutes = now.getMinutes();

        var seconds = now.getSeconds();


        hours = (hours < 10 ? "0" : "") + hours;

        minutes = (minutes < 10 ? "0" : "") + minutes;

        seconds = (seconds < 10 ? "0" : "") + seconds;


        var timeString = hours % 12 + ":" + minutes + ":" + seconds + " " + (hours < 12 ? "AM" : "PM");


        document.getElementById("clock").innerHTML = timeString;

        setTimeout(updateClock, 1000);

    }


    updateClock();


    function toggleLogoutButton() {

        var logoutButton = document.getElementById('logoutButton');

        logoutButton.style.display = (logoutButton.style.display === 'block') ? 'none' : 'block';

    }


    function toggleMenu() {

        var menuContent = document.querySelector('.menu-content');

        menuContent.classList.toggle('show');

    }


    function logout() {

        alert('Logged out successfully!');

    }


    function showBookingForm() {

        var bookingFormContainer = document.getElementById('bookingFormContainer');

        if (bookingFormContainer.style.display === 'none' || bookingFormContainer.style.display === '') {

            bookingFormContainer.style.display = 'block';

        } else {

            bookingFormContainer.style.display = 'none';

        }

    }

</script>
</body>

</html><?php /**PATH C:\xampp\htdocs\railway-system\resources\views/dashboard.blade.php ENDPATH**/ ?>