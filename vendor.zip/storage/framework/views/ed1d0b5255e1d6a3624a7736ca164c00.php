<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>User Profile</title>

    <!-- Add Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Add FontAwesome for experience icon -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        body {
            background: rgb(99, 39, 120);
        }

        .form-control:focus {
            box-shadow: none;
            border-color: #BA68C8;
        }

        .profile-button {
            background: rgb(99, 39, 120);
            box-shadow: none;
            border: none;
        }

        .profile-button:hover {
            background: #682773;
        }

        .profile-button:focus {
            background: #682773;
            box-shadow: none;
        }

        .profile-button:active {
            background: #682773;
            box-shadow: none;
        }

        .back:hover {
            color: #682773;
            cursor: pointer;
        }

        .labels {
            font-size: 11px;
        }

        .add-experience:hover {
            background: #BA68C8;
            color: #fff;
            cursor: pointer;
            border: solid 1px #BA68C8;
        }

        .container {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            margin-top: 50px;
            margin-bottom: 50px;
        }

        .rounded-circle {
            margin-top: 30px;
        }

        .text-danger {
            font-size: 12px;
        }
    </style>
</head>
<body>

<div class="container rounded bg-white mt-5 mb-5">
    <div class="row">
        <div class="col-md-3 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <!-- Display profile picture -->
                <img class="rounded-circle mt-5" width="150px" src="<?php echo e($user->profile_picture ? asset('storage/' . $user->profile_picture) : 'https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg'); ?>" alt="User Photo">
                <span class="font-weight-bold"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></span>
                <span class="text-black-50"><?php echo e($user->email); ?></span>
            </div>
        </div>
        <div class="col-md-9">
            <!-- Start of Profile Form -->
            <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="p-3 py-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="text-right">Profile Settings</h4>
                    </div>

                    <!-- Displaying Success Message -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Displaying Errors -->
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="row mt-2">
                        <div class="col-md-6">
                            <label class="labels">First Name</label>
                            <input type="text" class="form-control" name="first_name" placeholder="First Name" value="<?php echo e(old('first_name', $user->first_name)); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="labels">Last Name</label>
                            <input type="text" class="form-control" name="last_name" placeholder="Last Name" value="<?php echo e(old('last_name', $user->last_name)); ?>">
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Email Address</label>
                            <input type="email" class="form-control" name="email" placeholder="Email Address" value="<?php echo e(old('email', $user->email)); ?>">
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Password" value="<?php echo e(old('password')); ?>">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Confirm Password</label>
                            <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <label class="labels">Gender</label>
                            <select class="form-control" name="gender">
                                <option value="male" <?php echo e(old('gender', $user->gender) == 'male' ? 'selected' : ''); ?>>Male</option>
                                <option value="female" <?php echo e(old('gender', $user->gender) == 'female' ? 'selected' : ''); ?>>Female</option>
                                <option value="other" <?php echo e(old('gender', $user->gender) == 'other' ? 'selected' : ''); ?>>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="labels">Date of Birth</label>
                            <input type="date" class="form-control" name="dob" value="<?php echo e(old('dob', $user->dob)); ?>">
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Mobile Number</label>
                            <input type="text" class="form-control" name="mobile" placeholder="Mobile Number" value="<?php echo e(old('mobile', $user->mobile)); ?>">
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Marital Status</label>
                            <select class="form-control" name="marital_status">
                                <option value="single" <?php echo e(old('marital_status', $user->marital_status) == 'single' ? 'selected' : ''); ?>>Single</option>
                                <option value="married" <?php echo e(old('marital_status', $user->marital_status) == 'married' ? 'selected' : ''); ?>>Married</option>
                                <option value="divorced" <?php echo e(old('marital_status', $user->marital_status) == 'divorced' ? 'selected' : ''); ?>>Divorced</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Profile Picture</label>
                            <input type="file" class="form-control" name="profile_picture">
                        </div>
                    </div>

                    <div class="mt-5 text-center">
                        <button class="btn btn-primary profile-button" type="submit">Save Profile</button>
                    </div>
                </div>
            </form>
            <!-- End of Profile Form -->
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\railway-system\resources\views/profile.blade.php ENDPATH**/ ?>