<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{// UserController.php

public function profile()
{
    // Get the currently authenticated user
    $user = auth()->user();

    // Return the profile view with the user data
    return view('profile', compact('user'));
}

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        // Validate the input fields
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email,' . $id,
            'password' => 'nullable|string|min:8|confirmed',
            'gender' => 'required|string',
            'dob' => 'required|date',
            'mobile' => 'required|string|max:15',
            'marital_status' => 'required|string',
            'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Handle the profile picture if it's uploaded
        if ($request->hasFile('profile_picture')) {
            // Delete the old profile picture if it exists
            if ($user->profile_picture) {
                Storage::delete('public/' . $user->profile_picture);
            }

            // Store the new image in the 'profile_pictures' folder
            $imagePath = $request->file('profile_picture')->store('profile_pictures', 'public');
            $user->profile_picture = $imagePath;
        }

        // Update user data, excluding password if not provided
        $user->update($validated);

        // Redirect with success message
        return redirect()->route('profile')->with('success', 'Profile updated successfully!');
    }
}
