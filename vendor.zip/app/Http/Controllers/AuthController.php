<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        // Validate credentials
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        // Retrieve user by email
        $user = User::where('email', $request->email)->first();

        // Compare plain-text password
        if ($user && $user->password === $request->password) {
            // Log in the user if passwords match
            Auth::login($user);

            // Regenerate session to prevent session fixation
            $request->session()->regenerate();

            // Redirect to the dashboard on successful login
            return redirect()->route('dashboard');
        }

        // Return to the login page with error message
        return back()->withErrors([
            'email' => 'The provided credentials are incorrect.',
        ])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        // Log out the user
        Auth::logout();

        // Invalidate the session and regenerate the CSRF token
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        // Redirect to the login page after logout
        return redirect('/login');
    }

    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        // Validate registration data
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'gender' => 'required|string',
            'dob' => 'required|date',
            'mobile' => 'required|string|max:15',
            'marital_status' => 'required|string',
        ]);
    
        // Create user and save plain-text password
        $user = User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'password' => $request->password, // Save plain-text password
            'gender' => $request->gender,
            'dob' => $request->dob,
            'mobile' => $request->mobile,
            'marital_status' => $request->marital_status,
        ]);
    
        // Log in the newly registered user
        Auth::login($user);
    
        // Redirect to the dashboard after successful registration
        return redirect()->route('dashboard');
    }
}
