<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TicketPrice;

class BookingController extends Controller
{
    public function getTicketPrice(Request $request)
    {
        $request->validate([
            'from' => 'required|string',
            'to' => 'required|string',
            'class' => 'required|string',
            'ticketType' => 'required|string',
        ]);

        $ticketPrice = TicketPrice::where('from_station', $request->from)
            ->where('to_station', $request->to)
            ->where('class', $request->class)
            ->where('ticket_type', $request->ticketType)
            ->first();

        if ($ticketPrice) {
            return response()->json(['success' => true, 'ticketPrice' => $ticketPrice->price]);
        } else {
            return response()->json(['success' => false, 'message' => 'Ticket price not found.']);
        }
    }
}