<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'age',
        'sex',
        'from_station',
        'to_station',
        'journey_date',
        'journey_type',
        'class',
        'ticket_type',
        'payment_method',
        'transaction_id',
        'user_id',
        'total_price'
    ];
}
