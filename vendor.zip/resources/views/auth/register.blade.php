<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, rgba(0, 112, 49, 0.8), rgba(0, 112, 49, 0.5));
            color: #fff;
        }

        /* Header Styles */
        .header {
            background-color: rgba(255, 255, 255, 0.9);
            width: 100%;
            height: 60px;
            padding: 10px;
            position: fixed;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            color: rgb(0, 112, 49);
            font-weight: bold;
            font-size: 24px; /* Reduced font size */
        }

        .rail-logo {
            width: 60px; /* Reduced logo size */
            height: auto;
            margin: 0 10px;
        }

        /* Login Page Styles */
        .login-page {
            padding-top: 70px; /* Adjusted for fixed header */
            height: 100vh;
            display: flex;
            background-image: url('image/metro1.jpg');

            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: rgba(255, 255, 255, 0.95);
            padding: 15px; /* Reduced padding */
            border-radius: 10px;
            width: 400px; /* Set a smaller fixed width */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            position: relative;
        }

        .login-text {
            text-align: center;
            margin-bottom: 15px; /* Reduced margin */
        }

        .login-text h1 {
            color: rgb(0, 112, 49);
            font-size: 20px; /* Reduced font size */
        }

        .login-text p {
            margin-top: 5px; /* Reduced margin */
            font-size: 14px; /* Reduced font size */
            color: #666;
        }

        .form-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px; /* Reduced margin */
        }

        .form-group {
            flex: 1;
            margin: 0 5px; /* Space between columns */
        }

        .form-group label {
            display: block;
            margin-bottom: 3px; /* Reduced margin */
            font-size: 12px; /* Reduced font size */
            color: rgb(0, 112, 49);
        }

        .login-box input[type="text"],
        .login-box input[type="password"],
        .login-box input[type="email"],
        .login-box input[type="date"],
        .login-box select {
            height: 35px; /* Reduced height */
            padding: 0 8px; /* Reduced padding */
            background: #f9f9f9;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 12px; /* Reduced font size */
            color: #333;
            width: 100%;
            box-sizing: border-box;
        }

        .login-box input[type="text"]:focus,
        .login-box input[type="password"]:focus,
        .login-box input[type="email"]:focus,
        .login-box input[type="date"]:focus,
        .login-box select:focus {
            outline: none;
            border-color: rgb(0, 112, 49);
        }

        .login-box button.btn {
            width: 100%;
            height: 35px; /* Reduced height */
            margin-top: 10px;
            background: rgb(0, 112, 49);
            border: none;
            color: #fff;
            font-size: 14px; /* Reduced font size */
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .login-box button.btn:hover {
            background: rgb(0, 90, 37); /* Darker shade for hover */
        }

        .login-social {
            margin-top: 15px; /* Reduced margin */
            text-align: center;
        }

        .login-social h3 {
            color: rgb(0, 112, 49);
            font-size: 14px; /* Reduced font size */
        }

        .login-social-buttons {
            margin-top: 10px;
            display: flex;
            justify-content: center;
        }

        .login-social-buttons a {
            margin: 0 5px; /* Reduced margin */
        }

        .login-social-buttons img {
            width: 20px; /* Reduced size */
            height: 20px; /* Reduced size */
        }

        .error-message {
            color: red;
            font-size: 12px; /* Reduced font size */
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        
        <div>
            <img src="image/logo.png" alt="Rail Logo" class="rail-logo">
        </div>
        <h1>Bangladesh Railway</h1>
        <div>
            <img src="image/mlogo.png" alt="Rail Logo" class="rail-logo">
        </div>
    </div>
    <div class="login-page">
        <div class="login-box">
            <div class="login-text">
                <h1>Sign Up</h1>
                <p>Fill in the details to create your account:</p>
            </div>
            <form role="form" action="{{ route('register') }}" method="post" class="login-form">
                @csrf
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input type="text" name="first_name" placeholder="First Name" required>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input type="text" name="last_name" placeholder="Last Name" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" placeholder="Password" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="password_confirmation">Confirm Password</label>
                        <input type="password" name="password_confirmation" placeholder="Confirm Password" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select name="gender" required>
                            <option value="" disabled selected>Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="dob">Date of Birth</label>
                        <input type="date" name="dob" required>
                    </div>
                    <div class="form-group">
                        <label for="mobile">Mobile</label>
                        <input type="text" name="mobile" placeholder="Mobile" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="marital_status">Marital Status</label>
                        <select name="marital_status" required>
                            <option value="" disabled selected>Select Marital Status</option>
                            <option value="single">Single</option>
                            <option value="married">Married</option>
                            <option value="divorced">Divorced</option>
                            <option value="widowed">Widowed</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn">Sign Up</button>
                <div class="login-social">
                    <h3>...or sign up with:</h3>
                    <div class="login-social-buttons">
                        <a href="https://google.com"><img src="image/google.png" alt="Google"></a>
                        <a href="https://twitter.com"><img src="image/twt.png" alt="Twitter"></a>
                        <a href="https://facebook.com"><img src="image/fb.png" alt="Facebook"></a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>