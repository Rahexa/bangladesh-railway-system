<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\SslCommerzPaymentController;



// Authentication Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']); // CSRF is automatically handled
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Registration Routes
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']); // CSRF is automatically handled

// Dashboard Route (auth middleware required)
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard')->middleware('auth');

// Profile Route (auth middleware required)
Route::get('/profile', [UserController::class, 'profile'])->name('profile')->middleware('auth');
Route::put('/user/{id}/update', [UserController::class, 'update'])->name('user.update')->middleware('auth');
Route::post('/booking', [BookingController::class, 'store'])->name('booking.store');

// Booking Routes
// Booking Routes (auth middleware required)

Route::get('/booking', [BookingController::class, 'create'])->name('booking.create')->middleware('auth'); // Show booking form

Route::post('/booking', [BookingController::class, 'store'])->name('booking.store'); // Store booking

Route::post('/get-ticket-price', [BookingController::class, 'getTicketPrice']);

// SSLCOMMERZ Start

// Other routes...
// SSLCOMMERZ Start
Route::get('/example1', [SslCommerzPaymentController::class, 'exampleEasyCheckout']);
Route::get('/example2', [SslCommerzPaymentController::class, 'exampleHostedCheckout']);

Route::post('/pay', [SslCommerzPaymentController::class, 'index']);
Route::post('/pay-via-ajax', [SslCommerzPaymentController::class, 'payViaAjax']);

Route::post('/success', [SslCommerzPaymentController::class, 'success']);
Route::post('/fail', [SslCommerzPaymentController::class, 'fail']);
Route::post('/cancel', [SslCommerzPaymentController::class, 'cancel']);

Route::post('/ipn', [SslCommerzPaymentController::class, 'ipn']);
