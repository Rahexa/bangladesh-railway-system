<?php

return [

    'driver' => env('SESSION_DRIVER', 'file'), // Session driver (file, cookie, database, etc.)
    
    'lifetime' => 120, // Session lifetime in minutes

    'expire_on_close' => false, // Expire the session on browser close

    'encrypt' => false, // Encrypt the session data

    'files' => storage_path('framework/sessions'), // Path to session files (if using file driver)

    'connection' => null, // Database connection (if using database driver)

    'table' => 'sessions', // Table name (if using database driver)

    'store' => null, // Cache store (if using cache driver)

    'lottery' => [2, 100], // Probability of garbage collection (1 in 100 chance)

    'cookie' => env('SESSION_COOKIE', 'laravel_session'), // Cookie name

    'path' => '/', // Cookie path

    'domain' => env('SESSION_DOMAIN', null), // Cookie domain

    'secure' => env('SESSION_SECURE_COOKIE', false), // Use secure cookies

    'http_only' => true, // HttpOnly flag for cookies

    'same_site' => 'lax', // SameSite attribute for cookies

];